from django.apps import AppConfig


class OrsapiConfig(AppConfig):
    name = 'ORSAPI'
